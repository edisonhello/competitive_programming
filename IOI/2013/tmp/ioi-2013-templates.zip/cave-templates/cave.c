#include "grader.h"

void exploreCave(int N) {
    /* ... */
}
