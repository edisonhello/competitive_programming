#ifndef __ROBOTS_H__
#define __ROBOTS_H__

#ifdef __cplusplus
extern "C" {
#endif

int putaway(int A, int B, int T, int X[], int Y[], int W[], int S[]);

#ifdef __cplusplus
}
#endif

#endif /* __ROBOTS_H__ */

