#ifndef __DREAMING_H__
#define __DREAMING_H__

#ifdef __cplusplus
extern "C" {
#endif

int travelTime(int N, int M, int L, int A[], int B[], int T[]);

#ifdef __cplusplus
}
#endif

#endif /* __DREAMING_H__ */

