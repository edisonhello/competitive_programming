#include "grader.h"

int travelTime(int N, int M, int L, int A[], int B[], int T[]) {
    return 42;
}
