#ifndef __ARTCLASS_H__
#define __ARTCLASS_H__

#ifdef __cplusplus
extern "C" {
#endif

int style(int H, int W, int R[500][500], int G[500][500], int B[500][500]);

#ifdef __cplusplus
}
#endif

#endif /* __ARTCLASS_H__ */

