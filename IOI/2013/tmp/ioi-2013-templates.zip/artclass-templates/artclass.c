#include "grader.h"

int style(int H, int W, int R[500][500], int G[500][500], int B[500][500]) {
    return 2;
}
